# Amazon-style Clone AI Reference Package

Contains 15 core reference screens.

- `screenshot/`: PNG visual references for each screen.
- `description/`: one Markdown implementation description per screen.

Covered flow: homepage, search results, category, product detail, cart, sign-in, account, orders, order details/tracking, lists, checkout address, checkout payment, order confirmation, help, and mobile responsive home.

The screenshots are **reference mockups**, not authenticated captures of Amazon's private account pages. Amazon's live pages vary by region, session, cookies, experiments and authentication. Use the package to guide an original Amazon-style ecommerce implementation with your own data, branding, assets and backend.
