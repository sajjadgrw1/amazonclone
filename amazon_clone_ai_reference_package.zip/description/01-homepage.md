# Amazon-style Home / Landing Page

## Purpose
Homepage with dark navy utility header, logo area, delivery location, large search bar, account/orders/cart controls, secondary category navigation, hero banner, product/category cards, deals rows, and footer. Recreate the hierarchy, spacing, dense ecommerce layout, hover states, responsive behavior, and reusable header/footer components. Keep content/data mock and do not depend on live Amazon APIs.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/homepage`
