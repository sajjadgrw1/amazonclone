# Search Results / Product Listing

## Purpose
Search-results page: same global header, breadcrumb, result count/title, left filter sidebar, sort control, product grid/list, ratings, prices, Prime-like delivery badge, pagination, and footer. Filters should be interactive and update URL/query state. Preserve Amazon-like density and alignment without hardcoding every product.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/search/results`
