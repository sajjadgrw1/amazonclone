# Category / Department Landing Page

## Purpose
Department landing page with category title, breadcrumb, subcategory tiles, promotional hero, featured products, popular brands, and recommendation rows. Use reusable cards and a consistent 1440px desktop container. Include sidebar/navigation behavior where appropriate.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/category`
