# Product Detail Page

## Purpose
Product detail page with image gallery on left, title/rating/review summary, price, savings, delivery/location block, variants, quantity, Add to Cart and Buy Now actions, seller/shipping info, product bullets, expandable details, and reviews section. Sticky purchase panel behavior should be documented.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/product/detail`
