# Your Account Dashboard

## Purpose
Account hub with greeting and a grid/list of account shortcuts: orders, login/security, addresses, payment options, lists, memberships, subscriptions, customer service, digital content, and preferences. Reuse global header and footer.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/account`
