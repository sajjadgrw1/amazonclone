# Your Orders

## Purpose
Orders management page with account header, search orders field, date/status filters, tabs or filter controls, order cards, item thumbnail, order date/total, shipping status, Track package, View details, Buy again, Return/replace, and review actions. Include empty/loading states.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/orders`
