# Your Lists / Wishlist

## Purpose
Lists page with list selector, create-list button, list title/description, privacy setting, item cards, quantity/price/availability, Add to Cart, move/delete controls, and empty-list state. Include list management modal.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/lists`
