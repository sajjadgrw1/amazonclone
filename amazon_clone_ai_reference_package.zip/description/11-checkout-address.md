# Checkout — Delivery Address

## Purpose
Checkout-only layout with progress indicator. Main content lists saved addresses, Add a new address form, delivery options, and Continue button. Right side order summary. Do not show normal shopping navigation beyond minimal checkout branding.

## AI implementation notes
- Build this as a reusable page in the clone rather than a static image.
- Reuse the global header, secondary navigation, footer, buttons, cards, typography, spacing, borders and responsive container from the other pages.
- Use mock JSON/local state for products, users, orders, addresses and payments.
- All buttons and controls should have sensible loading, validation, empty and error states.
- Match the supplied screenshot composition closely while keeping the implementation original and using mock content/assets.

## Main sections
- Global navigation/header
- Main page content described above
- Footer where applicable

## Suggested route
`/checkout/address`
