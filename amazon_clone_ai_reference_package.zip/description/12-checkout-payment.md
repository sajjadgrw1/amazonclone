# Checkout — Payment & Review

## Purpose
Payment step with checkout progress, saved payment methods, add-card form, billing address, order review, totals, and Place Order action.

## AI implementation notes
- Implement as a functional reusable page, not a static image.
- Reuse the global navigation, typography, spacing, cards and buttons from the other screens.
- Use mock local/API data and include loading, validation, empty and error states.
- Match the screenshot composition closely while using original/mock content and assets.

## Suggested route
`/checkout/payment`
