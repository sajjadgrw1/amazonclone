# Order Confirmation

## Purpose
Post-purchase success state with confirmation message, order number, delivery estimate, item summary, tracking/order buttons, and continue-shopping action.

## AI implementation notes
- Implement as a functional reusable page, not a static image.
- Reuse the global navigation, typography, spacing, cards and buttons from the other screens.
- Use mock local/API data and include loading, validation, empty and error states.
- Match the screenshot composition closely while using original/mock content and assets.

## Suggested route
`/order/confirmation`
