# Customer Service / Help

## Purpose
Help landing page with search, common topics, orders/returns/shipping/account categories, guided help cards, and support actions.

## AI implementation notes
- Implement as a functional reusable page, not a static image.
- Reuse the global navigation, typography, spacing, cards and buttons from the other screens.
- Use mock local/API data and include loading, validation, empty and error states.
- Match the screenshot composition closely while using original/mock content and assets.

## Suggested route
`/help`
