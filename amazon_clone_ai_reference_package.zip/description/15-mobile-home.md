# Mobile Home / Responsive Reference

## Purpose
Mobile responsive home screen with compact header, search, category navigation, hero, 2-column product grid and touch-friendly controls.

## AI implementation notes
- Implement as a functional reusable page, not a static image.
- Reuse the global navigation, typography, spacing, cards and buttons from the other screens.
- Use mock local/API data and include loading, validation, empty and error states.
- Match the screenshot composition closely while using original/mock content and assets.

## Suggested route
`/mobile/home`
